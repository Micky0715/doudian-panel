# 发布商品失败深度分析报告

- 日志文件: `[HOME]/doudian-panel/panel_data/logs/run_25595926_20260805_194201_46afcf20.log`
- 发布失败商品总数: **118**

## 一、按品牌分布（失败数降序）

### 华为 — 47 个失败

- **型号终检未通过(页面型号未选上/不匹配，拒绝发布)**: 36 个
  - Mate X7 典藏版: 5
  - Mate X5 典藏版: 5
  - nova 14 (活力版): 4
  - Mate 80 RS 非凡大师: 3
  - Mate 80 Pro Max: 3
  - Mate 70 Pro 优享版: 3
- **平台拒因/标题过长**: 8 个
  - Mate XT 非凡大师: 3
  - Mate 70 Pro+: 2
  - Mate XTs 非凡大师: 1
  - Mate X5 典藏版: 1
  - Mate X7 典藏版: 1
- **平台拒因/库存类**: 3 个
  - Mate 60: 3

### 三星 — 37 个失败

- **型号终检未通过(页面型号未选上/不匹配，拒绝发布)**: 13 个
  - Galaxy S26+: 3
  - Galaxy S25 Edge: 3
  - Galaxy S24+: 3
  - W26: 2
  - Galaxy S24 Ultra: 2
- **平台拒因/标题过长**: 10 个
  - Galaxy S23 Ultra: 6
  - Galaxy S25 Ultra: 3
  - Galaxy S24 Ultra: 1
- **处理异常/Locator.hover: Timeout 30000ms exceeded.**: 6 个
  - Galaxy S26 Ultra: 3
  - Galaxy S24 Ultra: 3
- **平台拒因/库存类**: 5 个
  - Galaxy Z Flip6: 2
  - W25: 1
  - W25 Flip: 1
  - Galaxy Z Fold5: 1
- **处理异常/未捕获详情**: 3 个
  - Galaxy Z Flip7 (5G版): 3

### 小米 — 30 个失败

- **型号终检未通过(页面型号未选上/不匹配，拒绝发布)**: 26 个
  - 13 Pro: 4
  - Redmi Note 14 Pro+: 3
  - Redmi Note 14: 3
  - REDMI K80 Pro: 3
  - REDMI K80 (至尊版): 3
  - Redmi Note 13 Pro: 2
- **平台拒因/库存类**: 4 个
  - 13: 2
  - 15: 2

### 一加 — 3 个失败

- **平台拒因/库存类**: 3 个
  - 13: 3

### 荣耀 — 1 个失败

- **平台拒因/标题过长**: 1 个
  - Magic7 RSR 保时捷: 1

## 二、按具体子原因分布（Top 全部）

- **型号终检未通过(页面型号未选上/不匹配，拒绝发布)**: 75 个
- **平台拒因/标题过长**: 19 个
- **平台拒因/库存类**: 15 个
- **处理异常/Locator.hover: Timeout 30000ms exceeded.**: 6 个
- **处理异常/未捕获详情**: 3 个

## 三、典型失败商品抽样（每类 3 个）

### 型号终检未通过(页面型号未选上/不匹配，拒绝发布) (75)

- `nova 14 (活力版)` | 【95新】Huawei/华为 华为 nova 14 (活力版) 二... (行 1301)
- `nova 12 Ultra` | 【95新】Huawei/华为 华为 nova 12 Ultra 二手手... (行 5515)
- `nova 14 (活力版)` | 【99新】智能二手手机华为 nova 14 (活力版) 国... (行 36959)

### 平台拒因/标题过长 (19)

- `Mate XTs 非凡大师` | 【99新】华为 Mate XTs 非凡大师 国行 全网通... (行 67217)
- `Mate XT 非凡大师` | 【99新】HUAWEI Mate XT 非凡大师 国行 全网通... (行 68075)
- `Mate XT 非凡大师` | 【99新】HUAWEI Mate XT 非凡大师 国行 全网通... (行 68467)

### 平台拒因/库存类 (15)

- `Mate 60` | 【95新】Mate 60 国行 全网通... (行 98524)
- `Mate 60` | 【95新】Mate 60 国行 全网通... (行 98888)
- `Mate 60` | 【95新】Mate 60 国行 全网通... (行 99251)

### 处理异常/Locator.hover: Timeout 30000ms exceeded. (6)

- `Galaxy S26 Ultra` | 【95新】三星 Galaxy S26 Ultra 国行 全网通... (行 46363)
- `Galaxy S26 Ultra` | 【95新】三星 Galaxy S26 Ultra 国行 全网通... (行 46700)
- `Galaxy S26 Ultra` | 【95新】三星 Galaxy S26 Ultra 国行 全网通... (行 52178)

### 处理异常/未捕获详情 (3)

- `Galaxy Z Flip7 (5G版)` | 【95新】三星 Galaxy Z Flip7 (5G版) 国行 全网... (行 48023)
- `Galaxy Z Flip7 (5G版)` | 【95新】三星 Galaxy Z Flip7 (5G版) 国行 全网... (行 49438)
- `Galaxy Z Flip7 (5G版)` | 【95新】三星 Galaxy Z Flip7 (5G版) 国行 全网... (行 51705)

