# 诊断：Find X9 被脚本改成 Find X9 Pro（Request Y）

日志：`run_7970406_20260806_112111_ab14ae03.log`（店铺 7970406，非 25595926）
商品：`【95新】OPPO OPPO Find X9 二手手机`，正确型号 = `Find X9`

## 现象
用户先把型号正确选成 `Find X9`，脚本后续又把它改成 `Find X9 Pro`。
最终回看(VERIFY)却“通过”，因为校验是宽松的包含判断（`Find X9 Pro 包含 Find X9`）。

## 完整时序（日志行号）
1. `1587` 关键字候选拆分：`['Find X9', 'Find']`（正确，来自 model=`Find X9`）
2. `1589` OPPO 钉死反推纯型号 = `Find X9`（正确），`1590-1595` 强制写入失败（form-instance-not-found）→ 回退通用关键字搜索
3. `1599-1606` 关键字 `Find X9`：精确点击 `Find X9`（正确）
4. `1607` **验证读到 `'二手优品'`**（错误的相邻 select 的值）→ `1608-1609` 判 `Find X9` 选择失败 → 继续下一个关键字
5. `1610-1616` 关键字 `Find`：列表遍历，`findBest` 用 keyword=`Find` 的 Level-2 规则（以 `Find ` 开头 + **按长度降序取最长**）→ 在可见项 `Find X9` / `Find X9 Pro` 中选了更长的 **`Find X9 Pro`**
6. `1618-1620` 点击 `Find X9 Pro`、校验稳定为 `Find X9 Pro`
7. `1621` ⚠ 提示 `Find X9 Pro` 是 `Find X9` 的扩展匹配（后续: Pro），“尝试下一个更精确关键字” —— 但候选已耗尽（`['Find X9','Find']`），无更多关键字
8. `1631` 回看 VERIFY：`Find X9 Pro 包含 Find X9` → 宽松通过

## 根因（两处叠加，都在 `test_doudian_batch.py`）

### 主因：验证探针用了“选项中心”而非“型号框中心”（与 Request V 同源）
- `_try_select_model_with_keyword` 内，`cx/cy` 在 `1942-1943` 被重写为**被点击选项的中心坐标**（来自 `select_result`）。
- 验证块 `verify` / `verify2`（行 `2004-2038`、`2063-2096`）以 `{"modelX": (cx if cx>0 else model_x), "modelY": (cy if cy>0 else model_y)}` 调用。
  因 `cx>0` 恒成立，`modelX/modelY` 实际 = **选项中心**，而非型号框中心。
- 下拉关闭后，选项原屏幕位置 (801,524) 已落在另一个 select（如 `二手优品`）框内 → 验证读到 `二手优品` → 把正确的 `Find X9` 误判失败。
- 这就是 Request V（P60→HUAWEI P60 Pro）同一类缺陷：验证探针没有钉死在型号框中心。之前的中心探针修复只覆盖了 `select_model` 内的 verify/guard，没覆盖到 `_try_select_model_with_keyword` 里这次的 verify（被 `cx/cy` 选项坐标“遮蔽”了）。

### 次因：`findBest` 忽略 original_model，广关键字取“最长变体”
- `findBest`（行 1870–1883）只按 `modelKeyword` 匹配；`originalModel` 在 1840 声明后**从未在 findBest 内使用**。
- keyword 回退到宽泛的 `"Find"` 时，Level-2 规则 `pre.sort((a,b)=>b.len-a.len)` **取最长**，于是 `Find X9 Pro` 击败 `Find X9`。
- 扩展匹配告警（1621）只记录、不回退，候选耗尽后错误变体残留。

## 修复方案（两处最小改动）

### 修复 A（治本，验证探针）
把 `verify` / `verify2` 的探针坐标固定为**型号框中心**，不要传选项中心 `cx/cy`。
- 在打开下拉前用 `pin` 拿到的型号框中心存到变量（如 `model_cx, model_cy = pin.get("cx"), pin.get("cy")`）。
- 验证调用改为 `{"modelX": model_cx, "modelY": model_cy}`（带兜底用 `model_x/model_y`）。
- 效果：选项点击后探针仍命中型号框，读到真实值 `Find X9`，不再误判失败，回退到 `Find` 关键字的分支根本不会触发。

### 修复 B（兜底，findBest 尊重 original_model）
在 `findBest` 顶部增加最高优先级：**精确匹配 original_model**。
```js
let om = (originalModel || modelKeyword);
for (let d of items){ let t=(d.innerText||'').trim(); if (t && t.toLowerCase()===om.toLowerCase()) return {el:d, matchLevel:0}; }
```
- 即使 keyword 仍是宽泛的 `Find`，只要可见项里有 `Find X9`（original），就优先选它，不会被 `Find X9 Pro` 抢走。
- `matchLevel<=2` 的即时返回逻辑对 0 同样生效，命中即返回。

## 结论
“一开始选对 Find X9 后被改成 Find X9 Pro” 的代码位置：
1. `_try_select_model_with_keyword` 的验证块（行 2004–2096）用选项中心当探针 → 误读 `二手优品` → 误判 `Find X9` 失败（主因，与 Request V 同源）；
2. 失败后回退广关键字 `Find`，`findBest`（行 1870–1883）取最长变体 → 选 `Find X9 Pro`（次因，original_model 未参与匹配）。
OPPO 钉死逻辑本身反推的纯型号是 `Find X9`（正确），不是元凶；它只是因强制写入失败而把流程交给了上面的通用搜索分支。

## 已应用修复（2026-08-06 12:23）
- **A（治本·验证探针）**：`_try_select_model_with_keyword` 新增 `model_cx/model_cy`，pin 成功时取型号框中心(`pin.cx/cy`)，失败兜底沿用 `model_x/model_y`；verify/verify2 改用 `model_cx/model_cy`，不再传被点击选项中心 `cx/cy`。→ 点完 Find X9 后探针仍命中型号框，读到真值，不再误读 `二手优品`，不触发回退到 `Find` 的分支。
- **C（根因·OPPO 钉死 gate）**：由原 `current_val == pure` 精确比较改为**归一化比较**（`_strip_brand_tokens` 剥离 OPPO 前缀后小写比对）。当页面型号框已是正确的带前缀值（如 `OPPO Find X9`）且归一化等于目标纯型号（`Find X9`）时，直接跳过重写，不进兜底搜索分支。即实现“页面已有值与目标型号归一化一致时，不要重选”。
- **验证**：`py_compile` 通过；normalize 用例（OPPO Find X9 / 双前缀 / 纯型号 / 扩展错型号 Find X9 Pro / 空值）skip 判定全 OK。
- 未实施：B（`findBest` 优先 original_model）——当前 A+C 已覆盖本场景，留作后续加固。
